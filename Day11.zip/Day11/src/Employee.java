public class Employee {
    String name;
}
