public class Manager {
    int managerAge;
    String eduQualification;
}
