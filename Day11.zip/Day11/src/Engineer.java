public class Engineer {
    double engineerSalary;
    String engineerUniversity;

}
