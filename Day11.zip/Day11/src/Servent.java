public class Servent {
    String serventDepartment;
    String serventAddress;

}
